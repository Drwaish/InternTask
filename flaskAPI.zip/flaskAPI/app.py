from flask import Flask, escape, request, render_template,send_file,redirect,url_for
from transformers import pipeline, set_seed
#initialization
set_seed(32)
generator = pipeline('text-generation', model="facebook/opt-125m", do_sample=True)

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("at.html")

@app.route('/api/completion', methods=['POST'])
def generatedText():
    sentence = str(request.form['sent'])
    print(sentence)
    var=generator(sentence)
    print(var[0]['generated_text'])
    return render_template('at.html', Output=var[0]['generated_text'])


if __name__ == '__main__':
    app.debug = True
    app.run()






