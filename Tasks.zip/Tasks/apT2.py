import streamlit as st
from rembg import remove
import matplotlib.pyplot as plt
import cv2
def removeBackground(input_path):
    #input = Image.open(input_path)
    output = remove(input_path)
    return output
img = st.file_uploader("Choose a file(.png only)", accept_multiple_files=False)
if img is not None:
    if st.button('Remove BackGround') :
        bytes_data = img.getvalue()
        out_img=removeBackground(bytes_data)



        btn=st.download_button(label='Image Download',
                   data=out_img,
                   file_name='out.png',
                   mime='image/png')
